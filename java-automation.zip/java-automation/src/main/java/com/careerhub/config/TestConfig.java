package com.careerhub.config;

/**
 * CareerHub Automation Testing Global Configuration
 */
public class TestConfig {
    public static final String BASE_UI_URL = System.getProperty("ui.url", "http://localhost:5173");
    public static final String BASE_API_URL = System.getProperty("api.url", "http://localhost:5000/api");
    public static final String MONGODB_URI = System.getProperty("mongodb.uri", "mongodb://127.0.0.1:27017/job_portal");

    public static final String CANDIDATE_EMAIL = "ansh@example.com";
    public static final String CANDIDATE_PASSWORD = "password123";

    public static final String RECRUITER_EMAIL = "recruiter@example.com";
    public static final String RECRUITER_PASSWORD = "password123";

    public static final int PAGE_LOAD_TIMEOUT_SECONDS = 15;
    public static final int EXPLICIT_WAIT_TIMEOUT_SECONDS = 10;
    public static final int IMPORTANT_PAGE_HOLD_SECONDS = 4;
}
