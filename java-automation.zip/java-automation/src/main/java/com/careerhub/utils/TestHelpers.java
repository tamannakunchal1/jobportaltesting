package com.careerhub.utils;

import com.careerhub.config.TestConfig;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

/**
 * Reusable Automation Helpers including the mandatory 4-second hold time on important pages,
 * wait synchronization, screenshot capture, and test data generators.
 */
public class TestHelpers {

    /**
     * Mandatory hold time requirement:
     * Dwell 4 seconds after an important page/modal has loaded its key content.
     */
    public static void holdImportantPage(WebDriver driver) {
        holdImportantPage(driver, TestConfig.IMPORTANT_PAGE_HOLD_SECONDS);
    }

    public static void holdImportantPage(WebDriver driver, int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Waits for element visibility with explicit wait
     */
    public static WebElement waitForVisibility(WebDriver driver, By locator) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(TestConfig.EXPLICIT_WAIT_TIMEOUT_SECONDS));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Waits for element to be clickable
     */
    public static WebElement waitForClickable(WebDriver driver, By locator) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(TestConfig.EXPLICIT_WAIT_TIMEOUT_SECONDS));
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    /**
     * Captures screenshot for test evidence
     */
    public static String captureScreenshot(WebDriver driver, String screenshotName) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            Path targetDir = Paths.get("target", "screenshots");
            Files.createDirectories(targetDir);
            Path targetPath = targetDir.resolve(screenshotName + "_" + timestamp + ".png");
            Files.copy(source.toPath(), targetPath);
            return targetPath.toAbsolutePath().toString();
        } catch (IOException e) {
            System.err.println("Failed to capture screenshot: " + e.getMessage());
            return null;
        }
    }

    public static String generateUniqueEmail(String prefix) {
        return prefix + "_" + System.currentTimeMillis() + "@careerhub.test";
    }
}
