package com.careerhub.pages;

import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Page Object for CareerHub Authentication Screen (Login & Registration)
 */
public class AuthPage {
    private final WebDriver driver;

    // Locators
    private final By nameInput = By.name("name");
    private final By emailInput = By.name("email");
    private final By passwordInput = By.name("password");
    private final By submitButton = By.cssSelector("button[type='submit']");
    private final By toggleAuthViewButton = By.xpath("//button[contains(text(), 'Sign in at gate') or contains(text(), 'Register counterfoil') or contains(text(), 'Need a new boarding pass') or contains(text(), 'Already holding a valid pass')]");
    private final By instantDemoButton = By.xpath("//button[contains(., 'Instant Demo')]");
    private final By candidateRoleButton = By.xpath("//button[contains(., 'Job Seeker') or contains(., 'Candidate')]");
    private final By recruiterRoleButton = By.xpath("//button[contains(., 'Recruiter') or contains(., 'Carrier')]");
    private final By authErrorAlert = By.cssSelector("div.p-2.px-3.mb-3, .invalid-feedback, div[style*='stamp-brick']");
    private final By headingLocator = By.xpath("//h4[contains(text(), 'Passenger Check-In') or contains(text(), 'Issue New Boarding Pass')]");

    public AuthPage(WebDriver driver) {
        this.driver = driver;
    }

    public void waitForLoad() {
        TestHelpers.waitForVisibility(driver, headingLocator);
        // Apply 4-second hold time on important page
        TestHelpers.holdImportantPage(driver);
    }

    public void switchToLoginView() {
        WebElement heading = driver.findElement(headingLocator);
        if (!heading.getText().contains("Passenger Check-In")) {
            driver.findElement(toggleAuthViewButton).click();
            TestHelpers.waitForVisibility(driver, By.xpath("//h4[contains(text(), 'Passenger Check-In')]"));
        }
    }

    public void switchToRegisterView() {
        WebElement heading = driver.findElement(headingLocator);
        if (!heading.getText().contains("Issue New Boarding Pass")) {
            driver.findElement(toggleAuthViewButton).click();
            TestHelpers.waitForVisibility(driver, By.xpath("//h4[contains(text(), 'Issue New Boarding Pass')]"));
        }
    }

    public void selectRole(String role) {
        if ("recruiter".equalsIgnoreCase(role)) {
            TestHelpers.waitForClickable(driver, recruiterRoleButton).click();
        } else {
            TestHelpers.waitForClickable(driver, candidateRoleButton).click();
        }
    }

    public void login(String email, String password) {
        switchToLoginView();
        TestHelpers.holdImportantPage(driver, 1);
        WebElement emailEl = TestHelpers.waitForVisibility(driver, emailInput);
        emailEl.clear();
        emailEl.sendKeys(email);
        TestHelpers.holdImportantPage(driver, 1);

        WebElement passEl = driver.findElement(passwordInput);
        passEl.clear();
        passEl.sendKeys(password);
        TestHelpers.holdImportantPage(driver, 1);

        driver.findElement(submitButton).click();
        TestHelpers.holdImportantPage(driver, 2);
    }

    public void register(String name, String email, String password, String role) {
        switchToRegisterView();
        TestHelpers.holdImportantPage(driver, 1);
        selectRole(role);
        TestHelpers.holdImportantPage(driver, 1);

        WebElement nameEl = TestHelpers.waitForVisibility(driver, nameInput);
        nameEl.clear();
        nameEl.sendKeys(name);
        TestHelpers.holdImportantPage(driver, 1);

        WebElement emailEl = driver.findElement(emailInput);
        emailEl.clear();
        emailEl.sendKeys(email);
        TestHelpers.holdImportantPage(driver, 1);

        WebElement passEl = driver.findElement(passwordInput);
        passEl.clear();
        passEl.sendKeys(password);
        TestHelpers.holdImportantPage(driver, 1);

        driver.findElement(submitButton).click();
        TestHelpers.holdImportantPage(driver, 2);
    }

    public void clickInstantDemo() {
        TestHelpers.holdImportantPage(driver, 1);
        TestHelpers.waitForClickable(driver, instantDemoButton).click();
        TestHelpers.holdImportantPage(driver, 2);
    }

    public String getErrorMessage() {
        try {
            WebElement errorEl = TestHelpers.waitForVisibility(driver, authErrorAlert);
            return errorEl.getText();
        } catch (Exception e) {
            return "";
        }
    }

    public boolean isNameFieldPresent() {
        List<WebElement> elements = driver.findElements(nameInput);
        return !elements.isEmpty() && elements.get(0).isDisplayed();
    }
}
