package com.careerhub.pages;

import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Page Object for CareerHub Main Concourse & Navigation Header
 */
public class ConcoursePage {
    private final WebDriver driver;

    // Navigation locators
    private final By terminalTab = By.xpath("//button[contains(@class, 'nav-counter-tab') and contains(., 'Terminal')]");
    private final By findPassesTab = By.xpath("//button[contains(@class, 'nav-counter-tab') and contains(., 'Find Passes')]");
    private final By boardedTab = By.xpath("//button[contains(@class, 'nav-counter-tab') and contains(., 'Boarded')]");
    private final By stubsTab = By.xpath("//button[contains(@class, 'nav-counter-tab') and contains(., 'Stubs')]");
    private final By dossierTab = By.xpath("//button[contains(@class, 'nav-counter-tab') and contains(., 'Dossier')]");
    private final By userProfilePill = By.xpath("//div[@title='View Passenger Dossier']");
    private final By logoutButton = By.cssSelector("button[title='Exit Concourse'], button[aria-label='Log Out']");
    private final By issueTicketButton = By.xpath("//button[contains(., 'Issue Ticket')]");
    private final By mobileMenuButton = By.cssSelector("button[aria-label='Toggle Menu']");
    private final By brandTitle = By.xpath("//span[contains(text(), 'CareerHub')]");

    public ConcoursePage(WebDriver driver) {
        this.driver = driver;
    }

    public void waitForLoad() {
        TestHelpers.waitForVisibility(driver, brandTitle);
        // Important Page 4-second hold
        TestHelpers.holdImportantPage(driver);
    }

    public void navigateToFindPasses() {
        try {
            WebElement tab = driver.findElement(findPassesTab);
            if (tab.isDisplayed()) {
                tab.click();
                return;
            }
        } catch (Exception ignored) {
        }
        // Fallback for tablet/mobile: open drawer
        driver.findElement(mobileMenuButton).click();
        TestHelpers.waitForVisibility(driver, By.cssSelector(".d-lg-none"));
        driver.findElement(By.xpath("//div[contains(@class, 'd-lg-none')]//button[contains(., 'Find Passes')]")).click();
    }

    public void navigateToBoarded() {
        try {
            WebElement tab = driver.findElement(boardedTab);
            if (tab.isDisplayed()) {
                tab.click();
                return;
            }
        } catch (Exception ignored) {
        }
        driver.findElement(mobileMenuButton).click();
        TestHelpers.waitForVisibility(driver, By.cssSelector(".d-lg-none"));
        driver.findElement(By.xpath("//div[contains(@class, 'd-lg-none')]//button[contains(., 'Boarded')]")).click();
    }

    public void navigateToStubs() {
        try {
            WebElement tab = driver.findElement(stubsTab);
            if (tab.isDisplayed()) {
                tab.click();
                return;
            }
        } catch (Exception ignored) {
        }
        driver.findElement(mobileMenuButton).click();
        TestHelpers.waitForVisibility(driver, By.cssSelector(".d-lg-none"));
        driver.findElement(By.xpath("//div[contains(@class, 'd-lg-none')]//button[contains(., 'Stubs')]")).click();
    }

    public void navigateToDossier() {
        try {
            driver.findElement(dossierTab).click();
        } catch (Exception e) {
            driver.findElement(userProfilePill).click();
        }
    }

    public void openPostJobModal() {
        TestHelpers.waitForClickable(driver, issueTicketButton).click();
    }

    public void logout() {
        TestHelpers.waitForClickable(driver, logoutButton).click();
        // Hold 4 seconds after logout transition
        TestHelpers.holdImportantPage(driver);
    }

    public boolean isLoaded() {
        try {
            return driver.findElement(logoutButton).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
