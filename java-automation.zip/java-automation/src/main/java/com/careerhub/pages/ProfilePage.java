package com.careerhub.pages;

import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Page Object for CareerHub Candidate Dossier (Profile View)
 */
public class ProfilePage {
    private final WebDriver driver;

    // Locators
    private final By editProfileButton = By.xpath("//button[contains(., 'Edit Dossier')]");
    private final By saveProfileButton = By.xpath("//button[contains(., 'Save Dossier Stamp') or contains(., 'Save')]");
    private final By headlineInput = By.name("headline");
    private final By phoneInput = By.name("phone");
    private final By newSkillInput = By.cssSelector("input[placeholder*='Attach a new skill stamp']");
    private final By attachSkillButton = By.xpath("//button[contains(., 'Attach Stamp')]");
    private final By skillTags = By.cssSelector(".tag-ticket-teal");
    private final By dossierHeading = By.xpath("//h4[contains(text(), 'Passenger Dossier Details')]");

    public ProfilePage(WebDriver driver) {
        this.driver = driver;
    }

    public void waitForLoad() {
        TestHelpers.waitForVisibility(driver, dossierHeading);
        // Important Page 4-second hold
        TestHelpers.holdImportantPage(driver);
    }

    public void clickEdit() {
        TestHelpers.holdImportantPage(driver, 1);
        TestHelpers.waitForClickable(driver, editProfileButton).click();
        TestHelpers.holdImportantPage(driver, 1);
    }

    public void updateHeadline(String headline) {
        WebElement input = TestHelpers.waitForVisibility(driver, headlineInput);
        input.clear();
        input.sendKeys(headline);
        TestHelpers.holdImportantPage(driver, 1);
    }

    public void addSkill(String skill) {
        WebElement input = TestHelpers.waitForVisibility(driver, newSkillInput);
        input.clear();
        input.sendKeys(skill);
        TestHelpers.holdImportantPage(driver, 1);

        WebElement attachBtn = driver.findElement(attachSkillButton);
        ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", attachBtn);
        ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("arguments[0].click();", attachBtn);
        TestHelpers.holdImportantPage(driver, 2);
    }

    public void saveProfile() {
        WebElement saveBtn = TestHelpers.waitForVisibility(driver, saveProfileButton);
        ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);
        ((org.openqa.selenium.JavascriptExecutor) driver).executeScript("arguments[0].click();", saveBtn);
        // Dwell 4 seconds after profile save
        TestHelpers.holdImportantPage(driver);
    }

    public int getSkillsCount() {
        return driver.findElements(skillTags).size();
    }
}
