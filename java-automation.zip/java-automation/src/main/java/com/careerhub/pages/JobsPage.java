package com.careerhub.pages;

import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Page Object for CareerHub Job Listings View ("Find Passes")
 */
public class JobsPage {
    private final WebDriver driver;

    // Locators
    private final By searchInput = By.cssSelector("input[placeholder*='Search by role'], input[placeholder*='keyword']");
    private final By locationSelect = By.xpath("//select[preceding-sibling::label[contains(text(), 'Location')] or contains(@class, 'form-select')][1]");
    private final By jobCards = By.cssSelector(".ticket-card, .ticket-receipt-row");
    private final By noResultsBanner = By.xpath("//h4[contains(text(), 'No Matching Passes Found')]");
    private final By resetFiltersButton = By.xpath("//button[contains(text(), 'RESET ALL') or contains(text(), 'Reset filters')]");
    private final By detailsButtons = By.xpath("//button[contains(., 'Details')]");
    private final By applyButtons = By.xpath("//button[contains(text(), 'APPLY') or contains(text(), 'BOARDED')]");
    private final By saveBookmarkButtons = By.cssSelector("button[aria-label='Save ticket'], button[title*='Save']");

    public JobsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void waitForLoad() {
        TestHelpers.waitForVisibility(driver, searchInput);
        // Important Page 4-second hold
        TestHelpers.holdImportantPage(driver);
    }

    public void searchByKeyword(String keyword) {
        WebElement input = TestHelpers.waitForVisibility(driver, searchInput);
        input.clear();
        input.sendKeys(keyword);
        // Dwell 4 seconds after search results populate
        TestHelpers.holdImportantPage(driver);
    }

    public void filterByLocation(String location) {
        List<WebElement> selects = driver.findElements(By.tagName("select"));
        if (!selects.isEmpty()) {
            Select select = new Select(selects.get(0));
            select.selectByVisibleText(location);
            TestHelpers.holdImportantPage(driver);
        }
    }

    public int getJobCardsCount() {
        return driver.findElements(jobCards).size();
    }

    public boolean isNoResultsDisplayed() {
        try {
            return driver.findElement(noResultsBanner).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void resetFilters() {
        try {
            driver.findElement(resetFiltersButton).click();
            TestHelpers.holdImportantPage(driver);
        } catch (Exception ignored) {
        }
    }

    public void openFirstJobDetails() {
        TestHelpers.holdImportantPage(driver, 1);
        List<WebElement> btns = driver.findElements(detailsButtons);
        if (!btns.isEmpty()) {
            btns.get(0).click();
            TestHelpers.holdImportantPage(driver, 1);
        }
    }

    public void clickFirstJobBookmark() {
        TestHelpers.holdImportantPage(driver, 1);
        List<WebElement> btns = driver.findElements(saveBookmarkButtons);
        if (!btns.isEmpty()) {
            btns.get(0).click();
            TestHelpers.holdImportantPage(driver, 2);
        }
    }
}
