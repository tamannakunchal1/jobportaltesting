package com.careerhub.pages;

import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Page Object for CareerHub Job Details Modal & Application Form
 */
public class JobDetailModalPage {
    private final WebDriver driver;

    // Locators
    private final By modalContainer = By.cssSelector(".modal-ticket-document");
    private final By jobTitleHeading = By.cssSelector(".modal-stub-header h3");
    private final By coverNoteTextarea = By.cssSelector("textarea[placeholder*='alignment']");
    private final By confirmAndBoardButton = By.xpath("//button[contains(., 'CONFIRM & BOARD')]");
    private final By alreadyBoardedBanner = By.xpath("//h6[contains(text(), 'BOARDING PASS ISSUED & CONFIRMED')]");
    private final By closeModalButton = By.cssSelector("button[aria-label='Close ticket modal']");

    public JobDetailModalPage(WebDriver driver) {
        this.driver = driver;
    }

    public void waitForLoad() {
        TestHelpers.waitForVisibility(driver, modalContainer);
        // Important Page 4-second hold on job details
        TestHelpers.holdImportantPage(driver);
    }

    public String getJobTitle() {
        return driver.findElement(jobTitleHeading).getText();
    }

    public void enterCoverNote(String note) {
        WebElement textarea = TestHelpers.waitForVisibility(driver, coverNoteTextarea);
        TestHelpers.holdImportantPage(driver, 1);
        textarea.clear();
        textarea.sendKeys(note);
        TestHelpers.holdImportantPage(driver, 2);
    }

    public void submitApplication() {
        TestHelpers.waitForClickable(driver, confirmAndBoardButton).click();
        // Hold 4 seconds to confirm submission confirmation state
        TestHelpers.holdImportantPage(driver);
    }

    public boolean isAlreadyBoardedConfirmed() {
        try {
            return driver.findElement(alreadyBoardedBanner).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void closeModal() {
        TestHelpers.holdImportantPage(driver, 1);
        TestHelpers.waitForClickable(driver, closeModalButton).click();
        TestHelpers.holdImportantPage(driver, 1);
    }
}
