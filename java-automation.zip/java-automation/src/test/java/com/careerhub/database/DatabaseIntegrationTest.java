package com.careerhub.database;

import com.careerhub.config.TestConfig;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.mindrot.jbcrypt.BCrypt;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static com.mongodb.client.model.Filters.eq;

/**
 * AREA 4: Java Database & Integration Testing
 * Uses official MongoDB Java Driver and jBCrypt to inspect actual database documents.
 */
public class DatabaseIntegrationTest {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> usersCollection;
    private MongoCollection<Document> jobsCollection;
    private MongoCollection<Document> applicationsCollection;

    @BeforeClass
    public void setupMongoConnection() {
        mongoClient = MongoClients.create(TestConfig.MONGODB_URI);
        database = mongoClient.getDatabase("job_portal");
        usersCollection = database.getCollection("users");
        jobsCollection = database.getCollection("jobs");
        applicationsCollection = database.getCollection("applications");
    }

    @AfterClass(alwaysRun = true)
    public void closeMongoConnection() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }

    @Test(priority = 1, description = "TC_JAVA_DB_01: Verify candidate user record exists in MongoDB")
    public void testUserRecordExistsInMongoDB() {
        Document candidateDoc = usersCollection.find(eq("email", TestConfig.CANDIDATE_EMAIL)).first();
        Assert.assertNotNull(candidateDoc, "Candidate document must exist in MongoDB 'users' collection");
        Assert.assertEquals(candidateDoc.getString("role"), "candidate");
        Assert.assertNotNull(candidateDoc.getObjectId("_id"));
    }

    @Test(priority = 2, description = "TC_JAVA_DB_02: Verify passwords in MongoDB are bcrypt hashes, NOT plaintext")
    public void testPasswordIsBcryptHashed() {
        Document candidateDoc = usersCollection.find(eq("email", TestConfig.CANDIDATE_EMAIL)).first();
        Assert.assertNotNull(candidateDoc);

        String storedPassword = candidateDoc.getString("password");

        // Assert not plaintext
        Assert.assertNotEquals(storedPassword, TestConfig.CANDIDATE_PASSWORD,
                "Password must NEVER be stored as plaintext in MongoDB");

        // Assert bcrypt prefix ($2a$ or $2b$)
        Assert.assertTrue(storedPassword.startsWith("$2a$") || storedPassword.startsWith("$2b$"),
                "Password must have valid bcrypt hash signature prefix");

        // Verify hash matches plaintext via BCrypt (jBCrypt standard revision adaptation)
        String compatibleHash = storedPassword.replaceFirst("^\\$2b\\$", "\\$2a\\$");
        boolean matches = BCrypt.checkpw(TestConfig.CANDIDATE_PASSWORD, compatibleHash);
        Assert.assertTrue(matches, "BCrypt.checkpw should successfully validate the stored password hash");
    }

    @Test(priority = 3, description = "TC_JAVA_DB_03: Verify jobs documents are saved with correct schema")
    public void testJobsDocumentsSchema() {
        Document jobDoc = jobsCollection.find().first();
        Assert.assertNotNull(jobDoc, "Jobs collection must contain seeded or created job documents");
        Assert.assertNotNull(jobDoc.getString("title"), "Job title must not be null");
        Assert.assertNotNull(jobDoc.getString("company"), "Company name must not be null");
        Assert.assertNotNull(jobDoc.getString("salary"), "Salary must not be null");
    }

    @Test(priority = 4, description = "TC_JAVA_DB_04: Verify application documents reference valid user and job ObjectIds")
    public void testApplicationDocumentReferences() {
        Document appDoc = applicationsCollection.find().first();
        if (appDoc != null) {
            ObjectId userId = appDoc.getObjectId("user");
            ObjectId jobId = appDoc.getObjectId("job");

            Assert.assertNotNull(userId, "Application must have valid user ObjectId");
            Assert.assertNotNull(jobId, "Application must have valid job ObjectId");

            // Verify referenced documents exist
            Document referencedUser = usersCollection.find(eq("_id", userId)).first();
            Assert.assertNotNull(referencedUser, "Referenced user must exist in users collection");

            Document referencedJob = jobsCollection.find(eq("_id", jobId)).first();
            Assert.assertNotNull(referencedJob, "Referenced job must exist in jobs collection");
        }
    }
}
