package com.careerhub.api;

import com.careerhub.config.TestConfig;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * AREA 3: REST API Automation Testing in Java using REST-Assured
 * Validates actual CareerHub Express backend contracts and HTTP response codes.
 */
public class CareerHubApiTest {

    private String candidateToken;
    private String recruiterToken;
    private String createdJobId;
    private final long timestamp = System.currentTimeMillis();

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = TestConfig.BASE_API_URL;
    }

    @Test(priority = 1, description = "TC_API_AUTH_01: Candidate Login returns HTTP 200 and JWT token")
    public void testCandidateLoginApi() {
        Map<String, String> payload = new HashMap<>();
        payload.put("email", TestConfig.CANDIDATE_EMAIL);
        payload.put("password", TestConfig.CANDIDATE_PASSWORD);

        Response response = given()
                .contentType(ContentType.JSON)
                .body(payload)
                .when()
                .post("/auth/login")
                .then()
                .statusCode(200)
                .time(lessThan(3000L), TimeUnit.MILLISECONDS)
                .body("success", equalTo(true))
                .body("token", notNullValue())
                .body("user.role", equalTo("candidate"))
                .extract()
                .response();

        candidateToken = response.path("token");
        Assert.assertNotNull(candidateToken, "JWT token must be extracted for subsequent requests");
    }

    @Test(priority = 2, description = "TC_API_AUTH_02: Recruiter Login returns HTTP 200 and recruiter role")
    public void testRecruiterLoginApi() {
        Map<String, String> payload = new HashMap<>();
        payload.put("email", TestConfig.RECRUITER_EMAIL);
        payload.put("password", TestConfig.RECRUITER_PASSWORD);

        Response response = given()
                .contentType(ContentType.JSON)
                .body(payload)
                .when()
                .post("/auth/login")
                .then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("user.role", equalTo("recruiter"))
                .extract()
                .response();

        recruiterToken = response.path("token");
    }

    @Test(priority = 3, description = "TC_API_AUTH_03: Login with invalid password returns HTTP 401")
    public void testLoginInvalidPasswordApi() {
        Map<String, String> payload = new HashMap<>();
        payload.put("email", TestConfig.CANDIDATE_EMAIL);
        payload.put("password", "IncorrectPassword123!");

        given()
                .contentType(ContentType.JSON)
                .body(payload)
                .when()
                .post("/auth/login")
                .then()
                .statusCode(401)
                .body("success", equalTo(false));
    }

    @Test(priority = 4, description = "TC_API_AUTH_04: Protected endpoint /auth/me returns 401 when token missing")
    public void testProtectedEndpointMissingTokenApi() {
        given()
                .when()
                .get("/auth/me")
                .then()
                .statusCode(401)
                .body("success", equalTo(false))
                .body("message", containsString("token missing"));
    }

    @Test(priority = 5, description = "TC_API_AUTH_05: Protected endpoint /auth/me returns user dossier when token valid")
    public void testProtectedEndpointValidTokenApi() {
        given()
                .header("Authorization", "Bearer " + candidateToken)
                .when()
                .get("/auth/me")
                .then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("user.email", equalTo(TestConfig.CANDIDATE_EMAIL))
                .body("stats.appliedCount", notNullValue());
    }

    @Test(priority = 6, description = "TC_API_JOB_01: Get jobs listing returns HTTP 200 and jobs array")
    public void testGetJobsListingApi() {
        given()
                .when()
                .get("/jobs")
                .then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("jobs", notNullValue());
    }

    @Test(priority = 7, description = "TC_API_JOB_02: Create new job opening as recruiter returns HTTP 201")
    public void testCreateJobApi() {
        Map<String, Object> jobPayload = new HashMap<>();
        jobPayload.put("title", "Lead Java Automation Engineer " + timestamp);
        jobPayload.put("company", "Oracle Cloud");
        jobPayload.put("location", "Bangalore");
        jobPayload.put("salary", "₹22 - ₹34 LPA");
        jobPayload.put("type", "Full Time");
        jobPayload.put("experience", "3-5 Years");

        Response response = given()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + recruiterToken)
                .body(jobPayload)
                .when()
                .post("/jobs")
                .then()
                .statusCode(201)
                .body("success", equalTo(true))
                .body("job.id", notNullValue())
                .extract()
                .response();

        createdJobId = response.path("job.id");
        Assert.assertNotNull(createdJobId, "Created Job ID must not be null");
    }

    @Test(priority = 8, dependsOnMethods = {"testCreateJobApi"}, description = "TC_API_JOB_03: Apply to created job returns HTTP 201")
    public void testApplyJobApi() {
        Map<String, String> appPayload = new HashMap<>();
        appPayload.put("jobId", createdJobId);
        appPayload.put("coverNote", "REST-Assured automated submission.");

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + candidateToken)
                .body(appPayload)
                .when()
                .post("/applications")
                .then()
                .statusCode(201)
                .body("success", equalTo(true))
                .body("application.status", equalTo("UNDER_REVIEW"));
    }

    @Test(priority = 9, dependsOnMethods = {"testApplyJobApi"}, description = "TC_API_JOB_04: Duplicate application returns HTTP 409 Conflict")
    public void testDuplicateApplicationReturns409Api() {
        Map<String, String> appPayload = new HashMap<>();
        appPayload.put("jobId", createdJobId);
        appPayload.put("coverNote", "Duplicate submission attempt.");

        given()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer " + candidateToken)
                .body(appPayload)
                .when()
                .post("/applications")
                .then()
                .statusCode(409)
                .body("success", equalTo(false));
    }

    @Test(priority = 10, dependsOnMethods = {"testCreateJobApi"}, description = "TC_API_SAVE_01: Bookmark and toggle saved job returns HTTP 200")
    public void testToggleSavedJobApi() {
        // Bookmark
        given()
                .header("Authorization", "Bearer " + candidateToken)
                .when()
                .post("/saved-jobs/" + createdJobId)
                .then()
                .statusCode(200)
                .body("success", equalTo(true));
    }

    @Test(priority = 11, description = "TC_API_STAT_01: Departure stats concourse returns HTTP 200")
    public void testDepartureStatsApi() {
        given()
                .when()
                .get("/stats")
                .then()
                .statusCode(200)
                .body("success", equalTo(true))
                .body("stats.totalJobs", greaterThan(0));
    }

    @Test(priority = 12, dependsOnMethods = {"testCreateJobApi"}, description = "TC_API_JOB_05: Clean up created job returns HTTP 200")
    public void testDeleteJobApi() {
        given()
                .header("Authorization", "Bearer " + recruiterToken)
                .when()
                .delete("/jobs/" + createdJobId)
                .then()
                .statusCode(200)
                .body("success", equalTo(true));
    }
}
