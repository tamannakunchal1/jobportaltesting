package com.careerhub.functional;

import com.careerhub.base.BaseTest;
import com.careerhub.pages.AuthPage;
import com.careerhub.pages.ConcoursePage;
import com.careerhub.pages.JobDetailModalPage;
import com.careerhub.pages.JobsPage;
import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * AREA 1 & 2: Java UI Automation Test — Job Application & Boarded Manifest
 */
public class JobApplicationTest extends BaseTest {

    private ConcoursePage concourse;

    @BeforeMethod
    public void loginToTerminal() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();
        authPage.clickInstantDemo();

        concourse = new ConcoursePage(driver);
        concourse.waitForLoad();
    }

    @Test(priority = 1, description = "TC_UI_APP_01: Apply for a job opening and verify boarding confirmation")
    public void testApplyForJobSubmission() {
        concourse.navigateToFindPasses();

        JobsPage jobsPage = new JobsPage(driver);
        jobsPage.waitForLoad();

        jobsPage.openFirstJobDetails();

        JobDetailModalPage modal = new JobDetailModalPage(driver);
        modal.waitForLoad();

        if (!modal.isAlreadyBoardedConfirmed()) {
            modal.enterCoverNote("Automated submission via Java Selenium test suite.");
            modal.submitApplication();
        }

        Assert.assertTrue(modal.isAlreadyBoardedConfirmed() || driver.getPageSource().contains("BOARDED"),
                "Boarding pass must be confirmed after application submission");
        TestHelpers.captureScreenshot(driver, "JobApplicationConfirmed");

        modal.closeModal();
    }

    @Test(priority = 2, description = "TC_UI_APP_02: Verify submitted passes appear in Boarded Manifest view")
    public void testBoardedManifestDisplay() {
        concourse.navigateToBoarded();
        TestHelpers.holdImportantPage(driver);

        boolean hasBoardedContent = driver.findElements(By.xpath("//h2[contains(text(), 'Boarded Passes Manifest')]")).size() > 0;
        Assert.assertTrue(hasBoardedContent, "Boarded Passes Manifest page must be displayed");
        TestHelpers.captureScreenshot(driver, "BoardedManifestDisplay");
    }
}
