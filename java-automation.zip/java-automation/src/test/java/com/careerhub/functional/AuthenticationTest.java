package com.careerhub.functional;

import com.careerhub.base.BaseTest;
import com.careerhub.config.TestConfig;
import com.careerhub.pages.AuthPage;
import com.careerhub.pages.ConcoursePage;
import com.careerhub.utils.TestHelpers;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * AREA 1 & 2: Java UI Automation Test — Authentication & Session Management
 */
public class AuthenticationTest extends BaseTest {

    @Test(priority = 1, description = "TC_UI_AUTH_01: Candidate Login with valid credentials")
    public void testCandidateLoginSuccess() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();

        authPage.login(TestConfig.CANDIDATE_EMAIL, TestConfig.CANDIDATE_PASSWORD);

        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        Assert.assertTrue(concourse.isLoaded(), "Concourse should load successfully after valid candidate login");
        TestHelpers.captureScreenshot(driver, "CandidateLoginSuccess");
    }

    @Test(priority = 2, description = "TC_UI_AUTH_02: Recruiter Login with valid credentials")
    public void testRecruiterLoginSuccess() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();

        authPage.login(TestConfig.RECRUITER_EMAIL, TestConfig.RECRUITER_PASSWORD);

        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        Assert.assertTrue(concourse.isLoaded(), "Concourse should load successfully after valid recruiter login");
        TestHelpers.captureScreenshot(driver, "RecruiterLoginSuccess");
    }

    @Test(priority = 3, description = "TC_UI_AUTH_03: Login with incorrect password displays error banner")
    public void testLoginIncorrectPassword() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();

        authPage.login(TestConfig.CANDIDATE_EMAIL, "WrongPassword999");

        String errorMsg = authPage.getErrorMessage();
        Assert.assertTrue(errorMsg.length() > 0, "Error banner should be displayed for incorrect credentials");
        TestHelpers.captureScreenshot(driver, "IncorrectPasswordFailure");
    }

    @Test(priority = 4, description = "TC_UI_AUTH_04: 1-Click Instant Demo login boards terminal directly")
    public void testInstantDemoLogin() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();

        authPage.clickInstantDemo();

        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        Assert.assertTrue(concourse.isLoaded(), "Terminal should load after Instant Demo click");
    }

    @Test(priority = 5, description = "TC_UI_AUTH_05: Candidate Registration with unique credentials")
    public void testCandidateRegistrationSuccess() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();

        String uniqueEmail = TestHelpers.generateUniqueEmail("java_candidate");
        authPage.register("Java Candidate", uniqueEmail, "SecurePass123", "candidate");

        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        Assert.assertTrue(concourse.isLoaded(), "Concourse should load after successful registration");
    }

    @Test(priority = 6, description = "TC_UI_AUTH_06: Logout clears session and redirects to check-in gate")
    public void testLogoutAndSessionCleared() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();
        authPage.clickInstantDemo();

        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        // Perform logout
        concourse.logout();

        // Verify check-in screen is visible again
        authPage.waitForLoad();
        Assert.assertTrue(authPage.isNameFieldPresent() || driver.getPageSource().contains("Check-In"),
                "User should be redirected to check-in screen after logout");
    }
}
