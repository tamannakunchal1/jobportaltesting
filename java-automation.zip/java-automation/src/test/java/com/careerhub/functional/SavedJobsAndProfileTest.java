package com.careerhub.functional;

import com.careerhub.base.BaseTest;
import com.careerhub.pages.AuthPage;
import com.careerhub.pages.ConcoursePage;
import com.careerhub.pages.JobsPage;
import com.careerhub.pages.ProfilePage;
import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * AREA 1 & 2: Java UI Automation Test — Saved Jobs (Stubs) & Profile Dossier
 */
public class SavedJobsAndProfileTest extends BaseTest {

    private ConcoursePage concourse;

    @BeforeMethod
    public void loginToTerminal() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();
        authPage.clickInstantDemo();

        concourse = new ConcoursePage(driver);
        concourse.waitForLoad();
    }

    @Test(priority = 1, description = "TC_UI_SAVE_01: Bookmark a job and verify in Stubs concourse")
    public void testSavedJobBookmark() {
        concourse.navigateToFindPasses();

        JobsPage jobsPage = new JobsPage(driver);
        jobsPage.waitForLoad();

        jobsPage.clickFirstJobBookmark();
        TestHelpers.holdImportantPage(driver, 2);

        concourse.navigateToStubs();
        TestHelpers.holdImportantPage(driver);

        boolean hasStubsContent = driver.findElements(By.xpath("//h2[contains(text(), 'Saved Ticket Stubs')]")).size() > 0;
        Assert.assertTrue(hasStubsContent, "Saved Ticket Stubs page should load");
        TestHelpers.captureScreenshot(driver, "SavedTicketStubsDisplay");
    }

    @Test(priority = 2, description = "TC_UI_PROF_01: Update candidate dossier and attach new skill tag")
    public void testUpdateCandidateDossier() {
        concourse.navigateToDossier();

        ProfilePage profilePage = new ProfilePage(driver);
        profilePage.waitForLoad();

        int initialSkills = profilePage.getSkillsCount();

        profilePage.clickEdit();
        profilePage.updateHeadline("Senior Automation Architect | Java & Playwright");
        profilePage.addSkill("Java-Selenium-Automation");
        profilePage.saveProfile();

        Assert.assertTrue(driver.getPageSource().contains("Senior Automation Architect"),
                "Updated headline should be reflected in candidate dossier");
        TestHelpers.captureScreenshot(driver, "UpdatedCandidateDossier");
    }
}
