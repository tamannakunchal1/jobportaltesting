package com.careerhub.functional;

import com.careerhub.base.BaseTest;
import com.careerhub.pages.AuthPage;
import com.careerhub.pages.ConcoursePage;
import com.careerhub.pages.JobDetailModalPage;
import com.careerhub.pages.JobsPage;
import com.careerhub.utils.TestHelpers;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * AREA 1 & 2: Java UI Automation Test — Job Search, Filtering, and Details
 */
public class JobManagementTest extends BaseTest {

    private ConcoursePage concourse;

    @BeforeMethod
    public void loginToTerminal() {
        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();
        authPage.clickInstantDemo();

        concourse = new ConcoursePage(driver);
        concourse.waitForLoad();
    }

    @Test(priority = 1, description = "TC_UI_JOB_01: Load job listings and verify cards exist")
    public void testJobListingsDisplay() {
        concourse.navigateToFindPasses();

        JobsPage jobsPage = new JobsPage(driver);
        jobsPage.waitForLoad();

        int count = jobsPage.getJobCardsCount();
        Assert.assertTrue(count > 0, "Jobs listing should display at least one departure pass card");
        TestHelpers.captureScreenshot(driver, "JobListingsDisplay");
    }

    @Test(priority = 2, description = "TC_UI_JOB_02: Search job openings by keyword")
    public void testKeywordSearch() {
        concourse.navigateToFindPasses();

        JobsPage jobsPage = new JobsPage(driver);
        jobsPage.waitForLoad();

        jobsPage.searchByKeyword("Java");
        int count = jobsPage.getJobCardsCount();
        Assert.assertTrue(count > 0, "Keyword search for 'Java' should return matching passes");
    }

    @Test(priority = 3, description = "TC_UI_JOB_03: Search with non-existent query displays 'No Matching Passes Found' banner")
    public void testFilterNoResultsAndReset() {
        concourse.navigateToFindPasses();

        JobsPage jobsPage = new JobsPage(driver);
        jobsPage.waitForLoad();

        jobsPage.searchByKeyword("NonExistentXYZ9999");
        Assert.assertTrue(jobsPage.isNoResultsDisplayed(), "No matching results card must be displayed");

        // Reset
        jobsPage.resetFilters();
        Assert.assertTrue(jobsPage.getJobCardsCount() > 0, "Resetting filters should restore all departure passes");
    }

    @Test(priority = 4, description = "TC_UI_JOB_04: Open Job Details Modal and verify specs breakdown")
    public void testJobDetailsModal() {
        concourse.navigateToFindPasses();

        JobsPage jobsPage = new JobsPage(driver);
        jobsPage.waitForLoad();

        jobsPage.openFirstJobDetails();

        JobDetailModalPage modal = new JobDetailModalPage(driver);
        modal.waitForLoad();

        String title = modal.getJobTitle();
        Assert.assertFalse(title.isEmpty(), "Modal job title should not be empty");
        TestHelpers.captureScreenshot(driver, "JobDetailModalDisplay");

        modal.closeModal();
    }
}
