package com.careerhub.crossbrowser;

import com.careerhub.base.BaseTest;
import com.careerhub.pages.AuthPage;
import com.careerhub.pages.ConcoursePage;
import com.careerhub.pages.JobsPage;
import com.careerhub.utils.TestHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * AREA 5: Java Cross-Browser & Responsive Automation Testing
 * Strictly Chromium & Edge/WebKit only. Firefox is prohibited.
 * Viewports: Desktop (1440x900), Tablet (768x1024), Mobile (390x844).
 */
public class CrossBrowserAndResponsiveTest extends BaseTest {

    @Test(priority = 1, description = "TC_RESP_01: Desktop Viewport Layout (1440x900)")
    public void testDesktopViewportLayout() {
        driver.manage().window().setSize(new Dimension(1440, 900));

        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();
        authPage.clickInstantDemo();

        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        // Verify desktop nav tabs are displayed
        Assert.assertTrue(driver.findElement(By.xpath("//nav[contains(@class, 'd-none d-lg-flex')]")).isDisplayed(),
                "Desktop navigation menu should be visible at 1440x900");
        TestHelpers.captureScreenshot(driver, "Responsive_Desktop_1440x900");
    }

    @Test(priority = 2, description = "TC_RESP_02: Tablet Viewport Layout (768x1024)")
    public void testTabletViewportLayout() {
        driver.manage().window().setSize(new Dimension(768, 1024));

        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();
        authPage.clickInstantDemo();

        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        concourse.navigateToFindPasses();
        JobsPage jobsPage = new JobsPage(driver);
        jobsPage.waitForLoad();

        Assert.assertTrue(jobsPage.getJobCardsCount() > 0, "Job cards should render cleanly on tablet viewport");
        TestHelpers.captureScreenshot(driver, "Responsive_Tablet_768x1024");
    }

    @Test(priority = 3, description = "TC_RESP_03: Mobile Viewport Layout (390x844)")
    public void testMobileViewportLayout() {
        driver.manage().window().setSize(new Dimension(390, 844));

        AuthPage authPage = new AuthPage(driver);
        authPage.waitForLoad();

        // Verify mobile check-in form fits cleanly without horizontal overflow
        Assert.assertTrue(driver.findElement(By.cssSelector("button[type='submit']")).isDisplayed(),
                "Submit button must remain accessible on mobile viewport");
        TestHelpers.captureScreenshot(driver, "Responsive_Mobile_Auth_390x844");

        authPage.clickInstantDemo();
        ConcoursePage concourse = new ConcoursePage(driver);
        concourse.waitForLoad();

        // Verify mobile menu button is present
        Assert.assertTrue(driver.findElement(By.cssSelector("button[aria-label='Toggle Menu']")).isDisplayed(),
                "Mobile hamburger toggle menu must be visible on mobile viewport");
        TestHelpers.captureScreenshot(driver, "Responsive_Mobile_Concourse_390x844");
    }
}
